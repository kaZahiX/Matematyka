#include <iostream>

int main()

{
std::cout << "Program obliczający pole koła\n";
 
float a = 15;
std::cout << "proszę wprowadzić promień koła\n";
std::cin >> a; 
std::cout << "promień:\n" "\n" << a << "\n ";
std::cout << "\nPole wynosi:\n";



std::cout <<   a * 3.14 * a ;























}























 




















