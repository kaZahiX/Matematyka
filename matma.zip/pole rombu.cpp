#include <iostream>

int main()
{
 
	
		float a = 12;
		


 

	
		float b = 14;
	

	float h = 5;

std::cout << "program obliczający pole trapezu\n";


std::cout << "proszę wprowadzić a: ";
std::cin >> a;  


std::cout << "proszę wprowadzić b: ";
std::cin >> b; 

std::cout << "proszę wprowadzić h: ";
std::cin >> h; 
std::cout << "\n";






if ( a > 0 and b > 0 and h > 0)

{
	std::cout << "Pole trapezu o: \n";

std::cout << "a = " << a << "\n";
std::cout << "b = " << b << "\n";
std::cout << "h = " << h << "\n";
std::cout << "wynosi ";



std::cout << (a + b ) * h / 2 << "\n"; 
}

else 
{
	std::cout << "wszystkie długości muszą być dodatnie\n";
	 
	  }







}



















